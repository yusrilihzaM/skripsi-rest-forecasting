
<!-- END layout-wrapper -->
<!-- JAVASCRIPT -->
<script src="<?= base_url(); ?>assets/libs/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/node-waves/waves.min.js"></script>

<script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>

<!-- datepicker -->
<script src="<?= base_url(); ?>assets/libs/air-datepicker/js/datepicker.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/air-datepicker/js/i18n/datepicker.en.js"></script>

<!-- apexcharts -->
<script src="<?= base_url(); ?>assets/libs/apexcharts/apexcharts.min.js"></script>

<script src="<?= base_url(); ?>assets/libs/jquery-knob/jquery.knob.min.js"></script>

<!-- Jq vector map -->
<script src="<?= base_url(); ?>assets/libs/jqvmap/jquery.vmap.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/jqvmap/maps/jquery.vmap.usa.js"></script>

<script src="<?= base_url(); ?>assets/js/pages/dashboard.init.js"></script>

<script src="<?= base_url(); ?>assets/js/app.js"></script>


<!-- Buttons examples -->
<script src="<?= base_url(); ?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/jszip/jszip.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="<?= base_url(); ?>assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<!-- Responsive examples -->
<script src="<?= base_url(); ?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<!-- Datatable init js -->
<script src="<?= base_url(); ?>assets/js/pages/datatables.init.js"></script>
<!-- Required datatable js -->
<script src="<?= base_url(); ?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

<!-- Summernote js -->

<!-- <script src="<?= base_url(); ?>assets/libs/summernote/summernote-bs4.min.js"></script> -->
<!-- <script src="<?= base_url(); ?>assets/libs/summernote/summernote-bs4.js"></script> -->
<!-- Sweet Alerts js -->
<script src="<?= base_url(); ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

<!-- Sweet alert init js-->
<script src="<?= base_url(); ?>assets/js/pages/sweet-alerts.init.js"></script>
<!-- init js -->
<!-- <script src="<?= base_url(); ?>assets/js/pages/summernote.init.js"></script> -->

<!-- <script type="text/javascript" src="<?= base_url(); ?>'assets/js/jquery-3.4.0.min.js'; ?>"></script> -->
<script type="text/javascript" src="<?= base_url(); ?>'assets/js/bootstrap.bundle.js'; ?>"></script>
<script src="<?= base_url() ?>assets/js/myscript.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>'assets/summernote/summernote-bs4.js'; ?>"></script>
<!-- Chart JS -->
<script src="<?= base_url() ?>assets/libs/chart.js/Chart.bundle.min.js"></script>
<script src="<?= base_url() ?>assets/js/pages/chartjs.init.js"></script>

<!-- Plugin Js-->
<script src="<?= base_url() ?>assets/libs/chartist/chartist.min.js"></script>
<script src="<?= base_url() ?>assets/libs/chartist-plugin-tooltips-updated/chartist-plugin-tooltip.min.js"></script>
<!-- demo js-->
<script src="<?= base_url() ?>assets/js/pages/chartist.init.js"></script>
<!-- Plugin Js-->
<script src="<?= base_url() ?>assets/libs/apexcharts/apexcharts.min.js"></script>
<!-- demo js-->
<script src="<?= base_url() ?>assets/js/pages/apex.init.js"></script>
</body>

</html>